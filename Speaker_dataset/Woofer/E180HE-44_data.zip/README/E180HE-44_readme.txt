Epique by Dayton Audio Driver Data Package - ReadMe

Model: E180HE-44
Type: 7" DVC MMAG Subwoofer 4 Ohm
Revision Date: 05/27/2021

Contents of the Data Package:

A) FRD Folder

This folder contains frequency response data for the driver in open-standard FRD 
format.

Off-axis data is provided at 0 degrees, 15 degrees, 30 degrees, 45 degrees and 60 degrees off-axis as follows:

"@0" = 0 degrees off-axis (on-axis measurement)
"@15" = 15 degrees off-axis
"@30" = 30 degrees off-axis
"@45" = 45 degrees off-axis
"@60" = 60 degrees off-axis

All data measured at 2.83Vrms at a distance of 1 meter. All FRD data files include 
nearfield measurement data below 450 Hz. Smoothing is 1/24 octave.

Off-axis data is not provided for compression drivers, subwoofers, or mini speakers.

B) GRAPH Folder

This folder includes PDF-format graphs for frequency response,impedance response, distortion and cumulative spectral decay data, plus parameter measurements. PDF files include vector-format graphics for 
scalability/zooming and reprinting.

Frequency response graph is produced using Dayton Audio OmniMic software. Off-axis data is included in the frequency response graph as follows:

Black trace: on-axis
Red trace: 15 degrees off-axis
Green trace: 30 degrees off-axis
Blue trace: 45 degrees off-axis
Orange trace: 60 degrees off-axis

Impedance response graph is produced using Dayton Audio DATS software.

Distortion response graph is produced using Dayton Audio OmniMic software displaying 2nd and 3rd harmonics. Smoothing is 1/12 octave. Driver amplitude appromately 95dB @ 1m on-axis as follows:.

Black trace: Fundamental 
Red trace: 2nd harmonic
Violet trace: 3rd harmonic 
Green trace: 4th harmonic
Purple trace: 2nd-5th harmonics

Percentage of distortion can be derived by noting how many dB down from the fundamental as follows:

-20 dB = 10%
-30 dB =  3%
-40 dB =  1%
-50 dB =  0.3%
-60 dB =  0.1%  

Cumulatative spectral decay graph is produced using Dayton Audio OmniMic software. All data measured on-axis 2.83Vrms at a distance of 1 meter. 

C) TEXT Folder

This folder includes text-format data exported from DATS software, for import into 
DATS or CLIO software.

"_dats" = text-format data exported for DATS software
"_clio" = text-format data exported for CLIO software

Text files include impedance data and Thiele-Small parameter data.

D) ZMA Folder

This folder contains impedance response data for the driver in open-standard ZMA 
format.

Impedance data measured in free air at 0.280 Vrms (1/10 watt) using DATS hardware. 
All drivers are exercised for minimum of 4 hours at 20-40% of Xmax before measuring 
parameters, to prevent effects of suspension creep and provide accurate data.

Compression driver impedance is measured without horn installed.

Support:

If additional support is needed, or if a problem with the data is discovered, contact
info@daytonaudio.com for assistance. Please include the affected driver model, and 
the name and version number of the software you are using to work with the data 
package, if applicable.

In critical performance applications, please check for the latest revision of this 
data package online before using, and discard all previous revisions.

