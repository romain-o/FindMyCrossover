GRS Driver Data Package - ReadMe

Model: 10SW-4HE
Type: 10" Paper Cone Rubber Surround High Excursion Subwoofer 4 Ohm
Revision Date: 6/13/2022

Contents of the Data Package:

A) FRD Folder

This folder contains frequency response data for the driver in open-standard FRD 
format.

On-axis data is provided at 0 degrees

All data measured at 2.83Vrms at a distance of 1 meter, with infinite baffle loading. 
All FRD data files include nearfield measurement data below 450 Hz. Smoothing is 1/24 
octave.

B) GRAPH Folder

This folder includes PDF-format graphs for frequency response and impedance response 
data, plus parameter measurements. PDF files include vector-format graphics for 
scalability/zooming and reprinting.

Frequency response graph is produced using Dayton Audio OmniMic software. On-axis data is included in the frequency response graph as follows:

Black trace: On-axis

Impedance response graph is produced using Dayton Audio DATS V2 software.

C) SPEC Folder

This folder includes a copy of the most recent GRS specification sheet for the driver including nominal Thiele-Small parameters, photo, drawing views, feature 
highlights, frequency response graph, and impedance response graph.

D) TEXT Folder

This folder includes text-format data exported from DATS V2 software, for import into 
DATS or CLIO software.

"_dats" = text-format data exported for DATS software
"_clio" = text-format data exported for CLIO software

Text files include impedance data and Thiele-Small parameter data.

E) ZMA Folder

This folder contains impedance response data for the driver in open-standard ZMA 
format.

Impedance data measured in free air at 0.280 Vrms (1/10 watt) using DATS V2 hardware. 

Compression driver impedance is measured without horn installed.

Support:

If additional support is needed, or if a problem with the data is discovered, contact
info@daytonaudio.com for assistance. Please include the affected driver model, and 
the name and version number of the software you are using to work with the data 
package, if applicable.

In critical performance applications, please check for the latest revision of this 
data package online before using, and discard all previous revisions. All parts of this
data package shall be considered to have the same revision status.

